*****instructions for compiling the program and running  it****

        1.  Go to path in terminal using cd "Path"
        2.  Firstly for the first program type "g++ Assgn3-Task1Src-<CS15BTECH11002>.cpp -lpthread" in terminal
        3.  This will compile the program and run it using "./a.out <number>" to get required output

        4.   For the second program type "g++ Assgn3-Task2Src-<CS15BTECH11002>.cpp " in terminal
        5.  This will compile the program and run it using "./a.out <number>" to get required output


        
